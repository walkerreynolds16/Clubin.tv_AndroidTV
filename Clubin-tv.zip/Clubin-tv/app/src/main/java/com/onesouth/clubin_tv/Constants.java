package com.onesouth.clubin_tv;

public class Constants {

    public static final String API_LINK = "https://clubin-tv-backend.herokuapp.com";
//    public static final String API_LINK = "http://10.0.2.2:5000/";

    public static final String YOUTUBE_API_KEY = "AIzaSyCDP05L_kQ697q03OmC_OFCbC1CoLb1RDY";

}
